module SausagesHelper
end
