class SayController < ApplicationController
  skip_before_action :authorize

  def thank_you
  end

  def good_bye
  end

  def welcome
  end

  def index
  end

end
