require 'test_helper'

class SausageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
